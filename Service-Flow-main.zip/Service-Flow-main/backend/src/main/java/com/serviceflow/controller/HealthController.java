package com.serviceflow.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class HealthController {

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
            "status",    "UP",
            "service",   "ServiceFlow Backend",
            "version",   "1.0.0",
            "timestamp", LocalDateTime.now().toString()
        );
    }
}
