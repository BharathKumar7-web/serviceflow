package com.serviceflow.repository;

import com.serviceflow.entity.User;
import com.serviceflow.entity.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    List<User> findByRole(Role role);

    List<User> findByRoleAndActiveTrue(Role role);

    @Query("SELECT u FROM User u WHERE u.role = :role AND u.active = true ORDER BY SIZE(u.assignedTickets) ASC")
    List<User> findLeastLoadedSupportAgents(Role role);
}
